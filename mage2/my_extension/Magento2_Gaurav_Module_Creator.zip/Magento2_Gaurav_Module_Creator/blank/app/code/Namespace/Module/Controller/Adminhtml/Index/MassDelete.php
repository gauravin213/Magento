<?php
/**
 * Copyright © 2015 Pagseguro. All rights reserved.
 */

namespace <Namespace>\<Module>\Controller\Adminhtml\Index;

class MassDelete extends \Magento\Backend\App\Action
{

    public function execute()
    {
        $MassStatusIds = $this->getRequest()->getParam('id');  
        //echo "<pre>"; print_r($MassStatusIds); die();

        $resultRedirect = $this->resultRedirectFactory->create();

	    if ($MassStatusIds) 
	    {
	    	foreach ($MassStatusIds as $id) 
	    	{
	        	$model = $this->_objectManager->create('<Namespace>\<Module>\Model\<Module>');
		        $model->load($id);
		        $model->delete();
		    }
		    // display success message
            $this->messageManager->addSuccess(__('The data has been deleted.'));
            // go to grid
            return $resultRedirect->setPath('*/*/');
           
	    } 
	    else 
	    {
	    	// display error message
	        $this->messageManager->addError(__('We can\'t find a data to delete.'));
	        // go to grid
	        return $resultRedirect->setPath('*/*/');
	    }
    }
}
