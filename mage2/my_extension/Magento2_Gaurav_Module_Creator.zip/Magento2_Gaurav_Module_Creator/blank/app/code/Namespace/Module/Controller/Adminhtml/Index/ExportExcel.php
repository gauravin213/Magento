<?php

namespace <Namespace>\<Module>\Controller\Adminhtml\Index;

class ExportExcel extends \Magento\Backend\App\Action
{

  protected $_fileFactory;
  protected $resultPageFactory;
  public function __construct
  ( 
    \Magento\Backend\App\Action\Context  $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Magento\Framework\App\Response\Http\FileFactory $fileFactory
  ) 
  {
    $this->resultPageFactory  = $resultPageFactory;

    $this->_fileFactory  = $fileFactory;

    parent::__construct($context);
  }

  public function execute()
    {
     
        $fileName = 'Bloger.xls';
        $content = $this->_view->getLayout()->createBlock(
            '<Namespace>\<Module>\Block\Adminhtml\<Module>\Grid'
        )->setSaveParametersInSession(
            true
        )->getExcel();
        return $this->_fileFactory->create($fileName, $content);
    }
    
}