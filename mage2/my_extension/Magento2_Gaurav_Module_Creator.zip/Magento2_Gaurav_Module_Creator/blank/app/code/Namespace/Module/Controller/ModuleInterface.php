<?php

namespace <Namespace>\<Module>\Controller;

use Magento\Framework\App\ActionInterface;

interface <Module>Interface extends ActionInterface
{
}
