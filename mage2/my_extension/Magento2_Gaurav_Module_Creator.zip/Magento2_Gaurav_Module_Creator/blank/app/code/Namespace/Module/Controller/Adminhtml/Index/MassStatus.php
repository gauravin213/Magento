<?php
/**
 * Copyright © 2015 Pagseguro. All rights reserved.
 */

namespace <Namespace>\<Module>\Controller\Adminhtml\Index;

class MassStatus extends \Magento\Backend\App\Action
{

    public function execute()
    {
    	$status = $this->getRequest()->getParam('status');

        $row_ids = $this->getRequest()->getParam('id');  

        $resultRedirect = $this->resultRedirectFactory->create();

        //echo "<pre>"; print_r($status); print_r($MassStatusIds); die();

        if ($status == 1) 
        {
        	//status enabled
        	$statusval = 1;
        } 
        else 
        {
        	//status disabled
        	$statusval = 0;
        }


	    if ($row_ids) 
	    {
	    	foreach ($row_ids as $id) 
	    	{
	        	$model = $this->_objectManager->create('<Namespace>\<Module>\Model\<Module>');
		        $model->load($id);
		        $model->setStatus($statusval);
		        $model->save();
		    }
            // display success message
            $this->messageManager->addSuccess(__('Your item status "enable" successffully.'));
            // go to grid
            return $resultRedirect->setPath('*/*/');
	    } 
	    else 
	    {
	    	$this->messageManager->addError(__('We can\'t find item to Status.'));
        	$this->_redirect('gaurav_sharma/*/');

            // display error message
            $this->messageManager->addError(__('We can\'t find item to Status.'));
            // go to grid
            return $resultRedirect->setPath('*/*/');
	    }
    }
}
