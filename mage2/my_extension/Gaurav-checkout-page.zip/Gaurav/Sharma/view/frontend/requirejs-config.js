var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Gaurav_Sharma/js/model/shipping-save-processor/default'
        }
    }
};