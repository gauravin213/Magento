<?php
namespace Gaurav\Sharma\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class AddHtmlToOrderShippingViewObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(\Magento\Framework\ObjectManagerInterface $objectManager)
    {
        $this->objectManager = $objectManager;
    }

    public function execute(EventObserver $observer)
    {

       
        //echo '==>'.$observer->getElementName(); echo "<br>";
   

        if($observer->getElementName() == 'order_shipping_view') {

            $orderShippingViewBlock = $observer->getLayout()->getBlock($observer->getElementName());
            $order = $orderShippingViewBlock->getOrder();
           
            $my_custom_fieldsBlock = $this->objectManager->create('Magento\Framework\View\Element\Template');

            $my_custom_fieldsBlock->setMyCustomFields($order->getMyCustomFields());

            $my_custom_fieldsBlock->setTemplate('Gaurav_Sharma::order_info_shipping_info.phtml');
            $html = $observer->getTransport()->getOutput() . $my_custom_fieldsBlock->toHtml();
            $observer->getTransport()->setOutput($html);
        }
    }
}