<?php
namespace Gaurav\Sharma\Block;
 
class Sharma extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
    {
        return 'Hello world!';
    }
}