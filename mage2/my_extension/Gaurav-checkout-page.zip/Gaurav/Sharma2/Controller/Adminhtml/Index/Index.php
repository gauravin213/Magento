<?php

namespace Gaurav\Sharma2\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
	
    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Gaurav_Sharma2::sharma2_manage');
    }

    /**
     * Sharma2 List action
     *
     * @return void
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu(
            'Gaurav_Sharma2::sharma2_manage'
        )->addBreadcrumb(
            __('Sharma2'),
            __('Sharma2')
        )->addBreadcrumb(
            __('Manage Sharma2'),
            __('Manage Sharma2')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Sharma2'));
        return $resultPage;
    }
}
