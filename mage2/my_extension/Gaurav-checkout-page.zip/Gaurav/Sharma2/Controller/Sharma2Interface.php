<?php

namespace Gaurav\Sharma2\Controller;

use Magento\Framework\App\ActionInterface;

interface Sharma2Interface extends ActionInterface
{
}
