<?php

namespace Gaurav\Sharma2\Controller\Index;

use Gaurav\Sharma2\Controller\Sharma2Interface;

class View extends \Gaurav\Sharma2\Controller\AbstractController\View implements Sharma2Interface
{

}
