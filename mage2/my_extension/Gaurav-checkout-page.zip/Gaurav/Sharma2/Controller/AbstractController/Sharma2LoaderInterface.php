<?php

namespace Gaurav\Sharma2\Controller\AbstractController;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;

interface Sharma2LoaderInterface
{
    /**
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return \Gaurav\Sharma2\Model\Sharma2
     */
    public function load(RequestInterface $request, ResponseInterface $response);
}
