<?php

namespace Gaurav\Sharma2\Controller\AbstractController;

use Magento\Framework\App\Action;
use Magento\Framework\View\Result\PageFactory;

abstract class View extends Action\Action
{
    /**
     * @var \Gaurav\Sharma2\Controller\AbstractController\Sharma2LoaderInterface
     */
    protected $sharma2Loader;
	
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Action\Context $context
     * @param OrderLoaderInterface $orderLoader
	 * @param PageFactory $resultPageFactory
     */
    public function __construct(Action\Context $context, Sharma2LoaderInterface $sharma2Loader, PageFactory $resultPageFactory)
    {
        $this->sharma2Loader = $sharma2Loader;
		$this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Sharma2 view page
     *
     * @return void
     */
    public function execute()
    {
        if (!$this->sharma2Loader->load($this->_request, $this->_response)) {
            return;
        }

        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		return $resultPage;
    }
}
