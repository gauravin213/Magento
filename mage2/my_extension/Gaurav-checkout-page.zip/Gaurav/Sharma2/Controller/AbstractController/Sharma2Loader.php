<?php

namespace Gaurav\Sharma2\Controller\AbstractController;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Registry;

class Sharma2Loader implements Sharma2LoaderInterface
{
    /**
     * @var \Gaurav\Sharma2\Model\Sharma2Factory
     */
    protected $sharma2Factory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $url;

    /**
     * @param \Gaurav\Sharma2\Model\Sharma2Factory $sharma2Factory
     * @param OrderViewAuthorizationInterface $orderAuthorization
     * @param Registry $registry
     * @param \Magento\Framework\UrlInterface $url
     */
    public function __construct(
        \Gaurav\Sharma2\Model\Sharma2Factory $sharma2Factory,
        Registry $registry,
        \Magento\Framework\UrlInterface $url
    ) {
        $this->sharma2Factory = $sharma2Factory;
        $this->registry = $registry;
        $this->url = $url;
    }

    /**
     * @param RequestInterface $request
     * @param ResponseInterface $response
     * @return bool
     */
    public function load(RequestInterface $request, ResponseInterface $response)
    {
        $id = (int)$request->getParam('id');
        if (!$id) {
            $request->initForward();
            $request->setActionName('noroute');
            $request->setDispatched(false);
            return false;
        }

        $sharma2 = $this->sharma2Factory->create()->load($id);
        $this->registry->register('current_sharma2', $sharma2);
        return true;
    }
}
