<?php
/**
 * Adminhtml sharma2 list block
 *
 */
namespace Gaurav\Sharma2\Block\Adminhtml;

class Sharma2 extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_sharma2';
        $this->_blockGroup = 'Gaurav_Sharma2';
        $this->_headerText = __('Sharma2');
        $this->_addButtonLabel = __('Add New Sharma2');
        parent::_construct();
        if ($this->_isAllowedAction('Gaurav_Sharma2::save')) {
            $this->buttonList->update('add', 'label', __('Add New Sharma2'));
        } else {
            $this->buttonList->remove('add');
        }
    }
    
    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}
