<?php

namespace Gaurav\Sharma2\Block;

/**
 * Sharma2 content block
 */
class Sharma2 extends \Magento\Framework\View\Element\Template
{
    /**
     * Sharma2 collection
     *
     * @var Gaurav\Sharma2\Model\ResourceModel\Sharma2\Collection
     */
    protected $_sharma2Collection = null;
    
    /**
     * Sharma2 factory
     *
     * @var \Gaurav\Sharma2\Model\Sharma2Factory
     */
    protected $_sharma2CollectionFactory;
    
    /** @var \Gaurav\Sharma2\Helper\Data */
    protected $_dataHelper;
    
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Gaurav\Sharma2\Model\ResourceModel\Sharma2\CollectionFactory $sharma2CollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Gaurav\Sharma2\Model\ResourceModel\Sharma2\CollectionFactory $sharma2CollectionFactory,
        \Gaurav\Sharma2\Helper\Data $dataHelper,
        array $data = []
    ) {
        $this->_sharma2CollectionFactory = $sharma2CollectionFactory;
        $this->_dataHelper = $dataHelper;
        parent::__construct(
            $context,
            $data
        );
    }
    
    /**
     * Retrieve sharma2 collection
     *
     * @return Gaurav\Sharma2\Model\ResourceModel\Sharma2\Collection
     */
    protected function _getCollection()
    {
        $collection = $this->_sharma2CollectionFactory->create();
        return $collection;
    }
    
    /**
     * Retrieve prepared sharma2 collection
     *
     * @return Gaurav\Sharma2\Model\ResourceModel\Sharma2\Collection
     */
    public function getCollection()
    {
        if (is_null($this->_sharma2Collection)) {
            $this->_sharma2Collection = $this->_getCollection();
            $this->_sharma2Collection->setCurPage($this->getCurrentPage());
            $this->_sharma2Collection->setPageSize($this->_dataHelper->getSharma2PerPage());
            $this->_sharma2Collection->setOrder('published_at','asc');
        }

        return $this->_sharma2Collection;
    }
    
    /**
     * Fetch the current page for the sharma2 list
     *
     * @return int
     */
    public function getCurrentPage()
    {
        return $this->getData('current_page') ? $this->getData('current_page') : 1;
    }
    
    /**
     * Return URL to item's view page
     *
     * @param Gaurav\Sharma2\Model\Sharma2 $sharma2Item
     * @return string
     */
    public function getItemUrl($sharma2Item)
    {
        return $this->getUrl('*/*/view', array('id' => $sharma2Item->getId()));
    }
    
    /**
     * Return URL for resized Sharma2 Item image
     *
     * @param Gaurav\Sharma2\Model\Sharma2 $item
     * @param integer $width
     * @return string|false
     */
    public function getImageUrl($item, $width)
    {
        return $this->_dataHelper->resize($item, $width);
    }
    
    /**
     * Get a pager
     *
     * @return string|null
     */
    public function getPager()
    {
        $pager = $this->getChildBlock('sharma2_list_pager');
        if ($pager instanceof \Magento\Framework\Object) {
            $sharma2PerPage = $this->_dataHelper->getSharma2PerPage();

            $pager->setAvailableLimit([$sharma2PerPage => $sharma2PerPage]);
            $pager->setTotalNum($this->getCollection()->getSize());
            $pager->setCollection($this->getCollection());
            $pager->setShowPerPage(TRUE);
            $pager->setFrameLength(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            )->setJump(
                $this->_scopeConfig->getValue(
                    'design/pagination/pagination_frame_skip',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )
            );

            return $pager->toHtml();
        }

        return NULL;
    }
}
