<?php

/**
 * Sharma2 Resource Collection
 */
namespace Gaurav\Sharma2\Model\ResourceModel\Sharma2;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Gaurav\Sharma2\Model\Sharma2', 'Gaurav\Sharma2\Model\ResourceModel\Sharma2');
    }
}
