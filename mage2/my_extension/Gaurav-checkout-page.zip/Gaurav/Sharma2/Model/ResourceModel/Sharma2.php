<?php

namespace Gaurav\Sharma2\Model\ResourceModel;

/**
 * Sharma2 Resource Model
 */
class Sharma2 extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('gaurav_sharma2', 'sharma2_id');
    }
}
