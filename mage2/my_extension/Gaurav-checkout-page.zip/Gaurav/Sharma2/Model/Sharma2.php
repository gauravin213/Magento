<?php

namespace Gaurav\Sharma2\Model;

/**
 * Sharma2 Model
 *
 * @method \Gaurav\Sharma2\Model\Resource\Page _getResource()
 * @method \Gaurav\Sharma2\Model\Resource\Page getResource()
 */
class Sharma2 extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Gaurav\Sharma2\Model\ResourceModel\Sharma2');
    }

}
